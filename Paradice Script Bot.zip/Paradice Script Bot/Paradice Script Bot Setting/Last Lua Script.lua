-- dicebot.lua

rCh1    = math.random(55,89)
rCh2    = math.random(5,54)
rCh3    = math.random(90,95)
chance  = (100-1)/3 -- sets your chance for placing a bet
bethigh = true -- bet high when true, bet low when false
div     = 10000
base    = balance/div
nextbet = base -- sets your first bet
maxbal  = balance

target = balance*1.10

function getmulti()
    payout=(100-1)/chance
    return payout/(payout-1)
end

function dobet()
    if balance >= target then
        stop()
    end

    if !win then
        rCh1 = math.random(55,95)
        bethigh = not bethigh
        chance = rCh1
        nextbet = previousbet * getmulti()
    else
        if currentstreak > 1 then
            rCh2 = math.random(5,54)
            chance = rCh2
            nextbet = previousbet * getmulti()
        else
            if balance>maxbal then
                maxbal  = balance
                base    = balance/div
                nextbet = base
            end
            rCh3    = math.random(90,95)
            chance  = rCh3
            nextbet = base
        end
    end

    if nextbet > balance then
        nextbet = balance
     end
end