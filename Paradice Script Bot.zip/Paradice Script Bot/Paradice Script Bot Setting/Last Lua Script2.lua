--[[

-- VOID HiLo

-- after winning, remember The Donation Box!
-- running tests of scripts 24/7 with pocket change can be tedious and often lose a lot,
-- before script is ready to make some profit - all doing that for common cause, so that you don't have to lose your money!
-- so be forth coming and kind and do not forget to donate a small % when you win - it all goes to make and test better scripts/bots:

-- for donations / tips:
-- TRX: TBVuXwHbVYWGUdnLsV8XpChqXmEgGfF4YN
-- DOGE: DNePXvC45oPsaTJZEZ6Hc3Yrj6FJbncR5H
-- LTC: Lho3848UfRGsqdMHTWKgmx6gWdNz6fVSKN
-- BCH: bitcoincash:qp2t26exha4drg89qsv379kq8qgatl6z85pet0zhhv

-- VOID HiLo

]]--

-- pass that amount of consecutive losses
LOSSES_STREAK_SAFE = 27

-- win target, -1 to disable
stopWin = -1

CHANGESEED_BET = 102

SwitchOnOfSequence = 'HHLLHL'

--------------------------------------------------------------
--------------------------------------------------------------
-- DON'T CHANGE !
chance  = 49.50
bets    = 0
divider = 0
for i   = LOSSES_STREAK_SAFE, 0, -1 do
divider += 2^i
end
function GetMinMartingaleStreak()
return balance / divider
end

nextbet = GetMinMartingaleStreak()

function SetHighLow()
local hl = string.sub( SwitchOnOfSequence, bets % string.len(SwitchOnOfSequence) + 1, bets % string.len(SwitchOnOfSequence) + 1 )
bethigh = hl == 'H' or hl == 'h'
end

function SetNextBet()
if win then
if stopWin > 0 and profit >= stopWin then
ching()
stop()
end

nextbet = GetMinMartingaleStreak()
else
nextbet = previousbet * 2
end
end

function CheckChangeSeed()
if CHANGESEED_BET > 0 and win and lastBet.nonce >= CHANGESEED_BET then
resetseed()
end
end

SetHighLow()
function dobet()
bets = bets + 1    
SetHighLow()
CheckChangeSeed()
SetNextBet()
end